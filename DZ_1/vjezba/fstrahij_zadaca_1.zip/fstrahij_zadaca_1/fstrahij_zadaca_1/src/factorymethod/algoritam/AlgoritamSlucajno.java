/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorymethod.algoritam;

import java.util.List;
import prototype.Mjesto;

/**
 *
 * @author Filip
 */
public class AlgoritamSlucajno implements Algoritam{

    @Override
    public Mjesto odrediMjesto(List<Mjesto> mjesta, int element) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Mjesto> getMjesta() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
